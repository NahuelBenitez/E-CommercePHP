<?php
include '../config/sesion.php';
include 'class.php';
?>
<html>
    <head>
       <?php include '../config/head.php' ;?>
       
    </head>
    <body>
   
        <?php include '../config/menu.php' ;?>
        <br>
        
        <h1 class="text-center">Modificar Credito (debe)</h1>
    <hr>
     <?php 
     $objetoMod=new registros2();
     $objetoMod->datoscredito($_GET['idproveedor']);
     ?>
        <?php
        if(isset($_POST['actividad'])){
            
            $objetomodificar = new registros2();
            $objetomodificar->moddebe($_POST['idproveedor'],$_POST['idusuario'],$_POST['actividad'],$_POST['debe']);
        }
        
        ?>
    </body>
</html>