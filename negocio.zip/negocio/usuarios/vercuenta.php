<?php
include '../config/sesion.php';
include 'class.php';
?>
<html>
    <head>
       <?php include '../config/head.php' ;?>
       
    </head>
    <body>
   
        <?php include '../config/menu.php' ;?>
        <br>
        <h1 class="text-center">CUENTA DEL PROVEEDOR</h1>
        <a class="btn btn-primary" href="nuevopago.php?idusuario=<?php echo $_GET['idusuario']; ?>">Nuevo Pago(haber)</a>
        <a class="btn btn-warning" href="nuevocredito.php?idusuario=<?php echo $_GET['idusuario']; ?>">Nuevo Credito(debe)</a>
        
        <hr>
        
        <?php
        $objetoMostrarcuenta = new registro2();
        $objetoMostrarcuenta->mostrarcuentaproveedor($_GET['idusuario']);
        ?>
    </body>
</html>