<?php
include 'class.php';
$objetoEliminar = new registros2();
$objetoEliminar->eliminarpc($_GET['idusuario'],$_GET['idproveedor']);
?>