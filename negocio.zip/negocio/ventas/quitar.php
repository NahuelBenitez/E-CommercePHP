<?php
    include 'class.php';
    $objetoQuitar=new ventas();
    $objetoQuitar->quitar($_GET['iddetalleventa']);
?>
