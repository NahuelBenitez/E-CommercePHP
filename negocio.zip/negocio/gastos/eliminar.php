<?php
   include 'class.php';
   
   $objetoEliminar =new eliminargasto();
   $objetoEliminar->eliminar($_GET['idgastos'])
   ?>

