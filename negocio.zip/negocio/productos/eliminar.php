<?php
   include 'class.php';
   
   $objetoEliminar =new eliminarproducto();
   $objetoEliminar->eliminar($_GET['id'])
   ?>

