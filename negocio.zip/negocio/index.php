<!doctype HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
        
        <link rel="shortcut icon" href="favicon (1).ico" type="image/x-icon">
        <link rel="icon" href="/favicon (1).ico" type="image/x-icon">
        
    </head>
    <body class="bg-dark" style="color: white">
        <h1 class="text-center" style="box-shadow: 5px 10px 15px #16a085">Inicio de Sesion</h1> <hr><br>
        <form action="validar.php" method="POST" style="width: 50%; margin: 0 auto; border: 5px #3498db solid; padding: 20px; border-radius: 20px; webkit-border-radius: 20px; mos-border-radius: 20px;">
        <div>
            <label>Usuario</label>
            <input type="text" class="form-control" name="usuario" placeholder="Ingrese Usuario" required="">
        </div>
        <div>
            <label>Contraseña</label>
            <input type="password" class="form-control" name="password" placeholder="Ingrese Contraseña" required="">
        </div><br>
            <div class="text-center">
                <button type="submit" class="btn btn-success btn-block">Ingresar</button>
                <button type="reset" class="btn btn-danger btn-block">Cancelar</button>
            </div><br>
            <p class="text-center"> <a  href="#">Olvidaste tu Contraseña?</a></p>
        
        
        </form>
        
        <div class="text-center fixed-bottom bg-info" style="border: 2px solid #2ecc71; border-radius: 20px; webkit-border-radius: 20px; mos-border-radius: 20px;">
            <footer><b>Desarrollado por Nahuel Benitez</b><br>
                <small>Copyright 2020 © | Todos los Derechos Reservados</small>
            </footer>
        </div>
        
    </body>
</html>
